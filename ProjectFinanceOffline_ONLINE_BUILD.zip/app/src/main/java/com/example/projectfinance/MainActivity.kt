package com.example.projectfinance

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

data class Project(val name:String, val contract:Long, val spent:Long, val remaining:Long, val progress:Int)
data class Expense(val title:String, val amount:Long, val category:String)

fun money(n:Long): String = NumberFormat.getNumberInstance(Locale.US).format(n) + " تومان"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val projects = remember { mutableStateListOf(
        Project("پروژه نمونه", 2_000_000_000, 850_000_000, 700_000_000, 46)
    )}
    val expenses = remember { mutableStateListOf(
        Expense("مصالح", 380_000_000, "پروژه"),
        Expense("دستمزد کارگران", 220_000_000, "پروژه"),
        Expense("پیمانکار", 150_000_000, "پروژه"),
        Expense("حمل و سوخت", 100_000_000, "پروژه")
    )}

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("مدیریت مالی پروژه") }) },
            bottomBar = {
                NavigationBar {
                    listOf("داشبورد","پروژه‌ها","هزینه‌ها","نقدینگی").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab==i, onClick={tab=i},
                            icon={ Icon(if(i==0) Icons.Default.Dashboard else if(i==1) Icons.Default.Business else if(i==2) Icons.Default.ReceiptLong else Icons.Default.AccountBalance, null) },
                            label={Text(label)}
                        )
                    }
                }
            }
        ) { p ->
            CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
                Box(Modifier.padding(p).fillMaxSize()) {
                    when(tab) {
                        0 -> Dashboard(projects, expenses)
                        1 -> Projects(projects)
                        2 -> Expenses(expenses)
                        3 -> Cashflow()
                    }
                }
            }
        }
    }
}

@Composable
fun Dashboard(projects: List<Project>, expenses: List<Expense>) {
    val p = projects.first()
    val finalCost = p.spent + p.remaining
    val profit = p.contract - finalCost
    LazyColumn(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("وضعیت کل کسب‌وکار", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold) }
        item { MetricCard("بهای تمام‌شده تا امروز", money(p.spent)) }
        item { MetricCard("برآورد هزینه باقی‌مانده", money(p.remaining)) }
        item { MetricCard("هزینه نهایی پیش‌بینی‌شده", money(finalCost)) }
        item { MetricCard("سود پیش‌بینی‌شده", money(profit), profit>=0) }
        item {
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("پیشرفت در برابر مصرف بودجه", fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("پیشرفت فیزیکی: ${p.progress}%")
                    Text("مصرف بودجه: ${((p.spent.toDouble()/p.contract)*100).toInt()}%")
                    if (p.spent.toDouble()/p.contract > p.progress/100.0)
                        Text("⚠️ هزینه پروژه نسبت به پیشرفت فیزیکی بیشتر است.")
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("تفکیک مالی", fontWeight=FontWeight.Bold)
                    Text("سود پروژه ≠ موجودی بانک ≠ مبلغ وام")
                    Text("هزینه‌های شخصی و باغ از هزینه واقعی پروژه جدا هستند.")
                }
            }
        }
    }
}

@Composable
fun MetricCard(title:String, value:String, positive:Boolean=true) {
    Card {
        Column(Modifier.padding(16.dp).fillMaxWidth()) {
            Text(title, style=MaterialTheme.typography.bodyMedium)
            Text(value, style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
        }
    }
}

@Composable
fun Projects(projects: MutableList<Project>) {
    var show by remember { mutableStateOf(false) }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text("پروژه‌ها", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
                Button(onClick={show=true}) { Text("پروژه جدید") }
            }
        }
        items(projects) { p ->
            Card { Column(Modifier.padding(16.dp)) {
                Text(p.name, fontWeight=FontWeight.Bold)
                Text("قرارداد: ${money(p.contract)}")
                Text("هزینه تا امروز: ${money(p.spent)}")
                Text("باقی‌مانده: ${money(p.remaining)}")
                Text("پیشرفت: ${p.progress}%")
            }}
        }
    }
    if(show) AlertDialog(onDismissRequest={show=false}, confirmButton={TextButton(onClick={show=false}){Text("باشه")}},
        title={Text("افزودن پروژه")}, text={Text("فرم کامل ثبت پروژه در نسخه بعدی اضافه می‌شود.")})
}

@Composable
fun Expenses(expenses: MutableList<Expense>) {
    var show by remember { mutableStateOf(false) }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text("هزینه‌های واقعی", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
                Button(onClick={show=true}) { Text("ثبت هزینه") }
            }
        }
        items(expenses) { e ->
            Card { Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                Column { Text(e.title, fontWeight=FontWeight.Bold); Text(e.category) }
                Text(money(e.amount))
            }}
        }
        item { Text("هزینه‌های شخصی، باغ و مالک/کارفرما در این فهرست به‌عنوان هزینه پروژه ثبت نمی‌شوند.") }
    }
    if(show) AlertDialog(onDismissRequest={show=false}, confirmButton={TextButton(onClick={show=false}){Text("باشه")}},
        title={Text("ثبت هزینه")}, text={Text("فرم ثبت مبلغ، تاریخ، سرفصل، پروژه و توضیحات در نسخه بعدی تکمیل می‌شود.")})
}

@Composable
fun Cashflow() {
    LazyColumn(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("جریان نقدی", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold) }
        item { MetricCard("موجودی فعلی", money(200_000_000)) }
        item { MetricCard("پرداخت‌های ماه آینده", money(300_000_000)) }
        item { MetricCard("مطالبات قابل دریافت", money(150_000_000)) }
        item { MetricCard("کسری احتمالی نقدینگی", money(0)) }
        item { Text("این بخش سود پروژه، موجودی نقد و وام را به‌صورت جداگانه نگهداری می‌کند.") }
    }
}
